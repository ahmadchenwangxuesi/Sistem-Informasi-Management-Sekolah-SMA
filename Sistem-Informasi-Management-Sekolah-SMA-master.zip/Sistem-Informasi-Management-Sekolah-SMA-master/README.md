# SIMS
Sistem Informasi Management Sekolah SMAN 1 Solok Selatan | Sumatera Barat


![1](https://cloud.githubusercontent.com/assets/12929878/9202873/246a88ac-407e-11e5-8a62-eb7900ff9533.jpg)
![2](https://cloud.githubusercontent.com/assets/12929878/9202874/24a201d8-407e-11e5-8385-8cb5fa066f4c.jpg)
![3](https://cloud.githubusercontent.com/assets/12929878/9202875/24ce3cee-407e-11e5-81ee-129d5bad6b9b.jpg)
![4](https://cloud.githubusercontent.com/assets/12929878/9202876/24d22f70-407e-11e5-83ca-05d645c89aa4.jpg)
![5](https://cloud.githubusercontent.com/assets/12929878/9202877/24d984be-407e-11e5-89f7-5fa55bd8266a.jpg)
